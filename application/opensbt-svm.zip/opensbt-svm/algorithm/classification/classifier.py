from enum import Enum

class ClassificationType(Enum):
    NONE = 0,
    DT = 1,
    SVM = 2,
    KNN = 3
