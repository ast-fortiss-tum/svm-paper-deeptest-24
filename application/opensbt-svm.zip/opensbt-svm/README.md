# NSGA-II-SVM Integration in OpenSBT

## Overview

This code provides the integration of NSGA-II-SVM into OpenSBT for performing case studies.

Make sure to install all requirements in a private environment using `pip install -r requirements.txt`.

Further installation instructions are available (here)[https://git.fortiss.org/opensbt/opensbt-core].

## Application

There are two case studies available, two related to mathematical benchmark problem runnable via `python run.py -e 1` and `python run.py -e 2`, and one with simplified simulator (Toy Exampe from OpenSBT). The Prescan system from the paper could not have been disclosed.