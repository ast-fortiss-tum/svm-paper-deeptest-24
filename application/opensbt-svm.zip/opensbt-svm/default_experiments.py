import os
from evaluation.fitness import *
from problem.adas_problem import ADASProblem
from problem.pymoo_test_problem import PymooTestProblem
from experiment.experiment_store import *
from algorithm.algorithm import *
from evaluation.critical import *
from simulation.dummy_simulation import DummySimulator

''' 3D test problem '''
def getExp1() -> Experiment:
    class CriticalKursawe(Critical):
        def eval(self, vector_fitness: np.ndarray, simout=None):
            return  (vector_fitness[0] > -19 ) and (vector_fitness[0] < -18 ) and \
                    (vector_fitness[1] < 0) and  (vector_fitness[1] > -4) or \
                        (vector_fitness[0] > -17 ) and (vector_fitness[0] < -14 ) and \
                    (vector_fitness[1] < -4) and  (vector_fitness[1] > -12)

    problem = PymooTestProblem(
        'kursawe', critical_function=CriticalKursawe())

    config = DefaultSearchConfiguration()
    config.maximal_execution_time = None
    config.n_generations = 5
    config.population_size = 20
    config.new_samples = 20
    config.n_func_evals_lim = 200
    config.ideal = np.asarray([-20,-20])
    config.ref_point_hv = np.asarray([-15,0])
    config.nadir = config.ref_point_hv

    # config.maximal_execution_time = None # limit the total time, to control the number of tree iterations
    experiment = Experiment(name="1",
                            problem=problem,
                            algorithm=AlgorithmType.NSGAII_SVM,
                            search_configuration=config)
    return experiment
experiments_store.register(getExp1())

def getExp2() -> Experiment:
    problem = PymooTestProblem(
        'BNH', critical_function=CriticalBnh())

    config = DefaultSearchConfiguration()
    config.maximal_execution_time = None
    config.population_size = 20
    config.n_generations = 5
    config.new_samples = 30
    config.n_func_evals_lim = 1000
    config.ideal = np.asarray([0,0])
    # config.ref_point_hv = np.asarray([140,50])
    config.ref_point_hv = np.asarray([70,20])
    config.nadir = config.ref_point_hv
    # config.maximal_execution_time = None # limit the total time, to control the number of tree iterations
    experiment = Experiment(
                            name="2",
                            problem=problem,
                            algorithm=AlgorithmType.NSGAII_SVM,
                            search_configuration=config)

    return experiment

experiments_store.register(getExp2())

def getExp100() -> Experiment:
    dummy_problem = ADASProblem(
                            problem_name="DummySimulatorProblem",
                            scenario_path="",
                            xl=[0, 1, 0, 1],
                            xu=[360, 3,360, 3],
                            simulation_variables=[
                                "orientation_ego",
                                "velocity_ego",
                                "orientation_ped",
                                "velocity_ped"],
                            fitness_function=FitnessAdaptedDistanceSpeed(),
                            critical_function=CriticalAdasAdaptedDistanceVelocity(),
                            simulate_function=DummySimulator.simulate,
                            simulation_time=10,
                            sampling_time=0.25
                            )
    config = DefaultSearchConfiguration()
    config.population_size = 20
    config.n_generations = 20
    config.new_samples = 30
    config.n_func_evals_lim = 1000

    config.ideal = np.asarray([-1,-5])
    config.nadir = np.asarray([-0.79,-0.09])

    experiment = Experiment(name="3",
                            problem=dummy_problem,
                            algorithm=AlgorithmType.NSGAII,
                            search_configuration=config)
    return experiment

experiments_store.register(getExp100())
