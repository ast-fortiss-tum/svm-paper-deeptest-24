from setuptools import setup, find_packages
setup(
    name = 'test_case_generation',
    packages = find_packages(),
)
# execute in shell: py setup.py install --user
# https://stackoverflow.com/questions/16981921/relative-imports-in-python-3