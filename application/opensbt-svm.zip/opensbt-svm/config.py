import os

DEBUG = False
SHOW_PLOT = False
RESULTS_FOLDER = os.sep + "results" + os.sep
WRITE_ALL_INDIVIDUALS = True
LOG_FILE = "." + os.sep + "log.txt"
